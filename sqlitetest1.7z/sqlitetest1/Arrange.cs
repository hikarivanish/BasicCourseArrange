﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace course
{
    static class Arrange
    {
        private static Random random = new Random();
        public static List<ClassChoice> arrange(List<ClassChoice> choices)
        {
            List<ClassChoice> newList = new List<ClassChoice>();
            foreach (ClassChoice item in choices)//generate a new list that has a random order
            {
                newList.Insert(random.Next(newList.Count), item);
            }
            List<ClassChoice> solution = new List<ClassChoice>();
            foreach (ClassChoice cc1 in newList)
            {
                foreach (ClassChoice cc2 in solution)
                {
                    if (cc2.IsConflictWith(cc1))
                    {
                        goto label1;
                    }
                }
                solution.Add(cc1);
            label1: ;
            }
            return solution;
        }
    }
}
